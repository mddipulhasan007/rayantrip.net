@include('layout.frontend.header')
      
    @include('frontend.banner-filter')
    @include('frontend.main-content')

@include('layout.frontend.footer')