</div>
      <section class="offers-section">
            <div class="container full-offer-sec">
                  <div class="d-flex align-items-center justify-content-between offer-main">
                        <div class="tab-left-side d-flex align-items-center offer-main-right">
                              <h3>Offers</h3>
                              <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                    <li class="nav-item">
                                          <a class="nav-link active" data-bs-toggle="pill" href="#pills-all-offer">
                                                All Offers
                                          </a>
                                    </li>
                                    <li class="nav-item">
                                          <a class="nav-link" data-bs-toggle="pill" href="#pills-bank-offer">
                                                Bank Offers
                                          </a>
                                    </li>
                                    <li class="nav-item">
                                          <a class="nav-link" data-bs-toggle="pill" href="#pills-flights">
                                                Flights
                                          </a>
                                    </li>
                                    <li class="nav-item">
                                          <a class="nav-link" data-bs-toggle="pill" href="#pills-hotels">
                                                Hotels
                                          </a>
                                    </li>
                                    <li class="nav-item">
                                          <a class="nav-link" data-bs-toggle="pill" href="#pills-visa">
                                                Visa
                                          </a>
                                    </li>
                                    <li class="nav-item">
                                          <a class="nav-link" data-bs-toggle="pill" href="#pills-tours">
                                                Tours
                                          </a>
                                    </li>
                                    <li class="nav-item">
                                          <a class="nav-link" data-bs-toggle="pill" href="#pills-trains">
                                                Trains
                                          </a>
                                    </li>
                                    <li class="nav-item">
                                          <a class="nav-link" data-bs-toggle="pill" href="#pills-cabs">
                                                cabs
                                          </a>
                                    </li>
                              </ul>
                        </div>
                        <a href="#" class="see-all-btn">View All <i class="fa-solid fa-arrow-right-long"></i></a>
                  </div>
                  <div class="tab-content" id="pills-tabContent">
                        <div class="container tab-pane active" id="pills-all-offer">
                              <div class="offer-slider">
                                    <div data-index="1" class="slick-slide" tabindex="-1" aria-hidden="true"
                                          style="outline: none; width: 295px;">
                                          <div>
                                                <div class="row">
                                                      <div class="col-md-6">
                                                            <a href="#" class="d-flex align-items-center">
                                                                  <div class="left-side">
                                                                        <img src="./assets/images/offer/offer-img-1.png"
                                                                              alt="...">
                                                                        <h5>T&C's Apply</h5>
                                                                  </div>
                                                                  <div class="right-side">
                                                                        <h3>Standard Chartered
                                                                        </h3>
                                                                        <h4><b>Interest-free
                                                                                    EMI* + Up to
                                                                                    35% OFF*</b>
                                                                        </h4>
                                                                        <p>on flights, hotels
                                                                              and holiday
                                                                              packages for your
                                                                              next trip.
                                                                        </p>
                                                                        <button class="btn btn-success"
                                                                              onclick=" window.open('http://makerayantrip.com','_blank')">
                                                                              Book Now</button>
                                                                  </div>
                                                            </a>
                                                      </div>
                                                      <div class="col-md-6">
                                                            <a href="#" class="d-flex align-items-center">
                                                                  <div class="left-side">
                                                                        <img src="./assets/images/offer/offer-img-2.png"
                                                                              alt="...">
                                                                        <h5>T&C's Apply</h5>
                                                                  </div>
                                                                  <div class="right-side">
                                                                        <h3>Standard Chartered
                                                                        </h3>
                                                                        <h4><b>Interest-free
                                                                                    EMI* + Up to
                                                                                    35% OFF*</b>
                                                                        </h4>
                                                                        <p>on flights, hotels
                                                                              and holiday
                                                                              packages for your
                                                                              next trip.
                                                                        </p>
                                                                        <button class="btn btn-success"
                                                                              onclick=" window.open('http://makerayantrip.com','_blank')">
                                                                              Book Now</button>
                                                                  </div>
                                                            </a>
                                                      </div>
                                                      <div class="col-md-6">
                                                            <a href="#" class="d-flex align-items-center">
                                                                  <div class="left-side">
                                                                        <img src="./assets/images/offer/offer-img-1.png"
                                                                              alt="...">
                                                                        <h5>T&C's Apply</h5>
                                                                  </div>
                                                                  <div class="right-side">
                                                                        <h3>Standard Chartered
                                                                        </h3>
                                                                        <h4><b>Interest-free
                                                                                    EMI* + Up to
                                                                                    35% OFF*</b>
                                                                        </h4>
                                                                        <p>on flights, hotels
                                                                              and holiday
                                                                              packages for your
                                                                              next trip.
                                                                        </p>
                                                                        <button class="btn btn-success"
                                                                              onclick=" window.open('http://makerayantrip.com','_blank')">
                                                                              Book Now</button>
                                                                  </div>
                                                            </a>
                                                      </div>
                                                      <div class="col-md-6">
                                                            <a href="#" class="d-flex align-items-center">
                                                                  <div class="left-side">
                                                                        <img src="./assets/images/offer/offer-img-2.png"
                                                                              alt="...">
                                                                        <h5>T&C's Apply</h5>
                                                                  </div>
                                                                  <div class="right-side">
                                                                        <h3>Standard Chartered
                                                                        </h3>
                                                                        <h4><b>Interest-free
                                                                                    EMI* + Up to
                                                                                    35% OFF*</b>
                                                                        </h4>
                                                                        <p>on flights, hotels
                                                                              and holiday
                                                                              packages for your
                                                                              next trip.
                                                                        </p>
                                                                        <button class="btn btn-success"
                                                                              onclick=" window.open('http://makerayantrip.com','_blank')">
                                                                              Book Now</button>
                                                                  </div>
                                                            </a>
                                                      </div>
                                                </div>
                                          </div>
                                    </div>
                                    <div data-index="2" class="slick-slide" tabindex="-1" aria-hidden="true"
                                          style="outline: none; width: 295px;">
                                          <div>
                                                <div class="row">
                                                      <div class="col-md-6">
                                                            <a href="#" class="d-flex align-items-center">
                                                                  <div class="left-side">
                                                                        <img src="./assets/images/offer/offer-img-1.png"
                                                                              alt="...">
                                                                        <h5>T&C's Apply</h5>
                                                                  </div>
                                                                  <div class="right-side">
                                                                        <h3>Standard Chartered
                                                                        </h3>
                                                                        <h4><b>Interest-free
                                                                                    EMI* + Up to
                                                                                    35% OFF*</b>
                                                                        </h4>
                                                                        <p>on flights, hotels
                                                                              and holiday
                                                                              packages for your
                                                                              next trip.
                                                                        </p>
                                                                        <button class="btn btn-success"
                                                                              onclick=" window.open('http://makerayantrip.com','_blank')">
                                                                              Book Now</button>
                                                                  </div>
                                                            </a>
                                                      </div>
                                                      <div class="col-md-6">
                                                            <a href="#" class="d-flex align-items-center">
                                                                  <div class="left-side">
                                                                        <img src="./assets/images/offer/offer-img-2.png"
                                                                              alt="...">
                                                                        <h5>T&C's Apply</h5>
                                                                  </div>
                                                                  <div class="right-side">
                                                                        <h3>Standard Chartered
                                                                        </h3>
                                                                        <h4><b>Interest-free
                                                                                    EMI* + Up to
                                                                                    35% OFF*</b>
                                                                        </h4>
                                                                        <p>on flights, hotels
                                                                              and holiday
                                                                              packages for your
                                                                              next trip.
                                                                        </p>
                                                                        <button class="btn btn-success"
                                                                              onclick=" window.open('http://makerayantrip.com','_blank')">
                                                                              Book Now</button>
                                                                  </div>
                                                            </a>
                                                      </div>
                                                      <div class="col-md-6">
                                                            <a href="#" class="d-flex align-items-center">
                                                                  <div class="left-side">
                                                                        <img src="./assets/images/offer/offer-img-1.png"
                                                                              alt="...">
                                                                        <h5>T&C's Apply</h5>
                                                                  </div>
                                                                  <div class="right-side">
                                                                        <h3>Standard Chartered
                                                                        </h3>
                                                                        <h4><b>Interest-free
                                                                                    EMI* + Up to
                                                                                    35% OFF*</b>
                                                                        </h4>
                                                                        <p>on flights, hotels
                                                                              and holiday
                                                                              packages for your
                                                                              next trip.
                                                                        </p>
                                                                        <button class="btn btn-success"
                                                                              onclick=" window.open('http://makerayantrip.com','_blank')">
                                                                              Book Now</button>
                                                                  </div>
                                                            </a>
                                                      </div>
                                                      <div class="col-md-6">
                                                            <a href="#" class="d-flex align-items-center">
                                                                  <div class="left-side">
                                                                        <img src="./assets/images/offer/offer-img-2.png"
                                                                              alt="...">
                                                                        <h5>T&C's Apply</h5>
                                                                  </div>
                                                                  <div class="right-side">
                                                                        <h3>Standard Chartered
                                                                        </h3>
                                                                        <h4><b>Interest-free
                                                                                    EMI* + Up to
                                                                                    35% OFF*</b>
                                                                        </h4>
                                                                        <p>on flights, hotels
                                                                              and holiday
                                                                              packages for your
                                                                              next trip.
                                                                        </p>
                                                                        <button class="btn btn-success"
                                                                              onclick=" window.open('http://makerayantrip.com','_blank')">
                                                                              Book Now</button>
                                                                  </div>
                                                            </a>
                                                      </div>
                                                </div>
                                          </div>
                                    </div>
                              </div>
                        </div>

                        <div class="container tab-pane fade" id="pills-bank-offer">
                              <p>Comming Soon 1</p>
                        </div>
                        <div class="container tab-pane fade" id="pills-flights">
                              <p>Comming Soon 2</p>
                        </div>
                        <div class="container tab-pane fade" id="pills-hotels">
                              <p>Comming Soon 3</p>
                        </div>
                        <div class="container tab-pane fade" id="pills-visa">
                              <p>Comming Soon 4-1</p>
                        </div>
                        <div class="container tab-pane fade" id="pills-tours">
                              <p>Comming Soon 4</p>
                        </div>
                        <div class="container tab-pane fade" id="pills-trains">
                              <p>Comming Soon 5</p>
                        </div>
                        <div class="container tab-pane fade" id="pills-cabs">
                              <p>Comming Soon 6</p>
                        </div>
                  </div>
            </div>
      </section>
      <section class="item-section-full">
            <div class="container">
                  <div class="items-slider">
                        <div class="item">
                              <img src="./assets/images/icons/air.png" alt="">
                              <div class="slide-item-right">
                                    <h4><b>Planning to book an international flight?</b></h4>
                                    <p>Call 0133-3535436 for booking assistance</p>
                              </div>
                        </div>
                        <div class="item">
                              <img src="./assets/images/icons/air-2.png" alt="">
                              <div class="slide-item-right">
                                    <h4><b>Complete your web check-in on MakeMyTrip in easy
                                                steps. </b></h4>
                                    <a href="#">Click to know more</a>
                              </div>
                        </div>
                        <div class="item">
                              <img src="./assets/images/icons/air.png" alt="">
                              <div class="slide-item-right">
                                    <h4><b>Check international destinations</b></h4>
                                    <p>Open for Indians here, with their guidelines</p>
                              </div>
                        </div>
                        <div class="item">
                              <img src="./assets/images/icons/air.png" alt="">
                              <div class="slide-item-right">
                                    <h4><b>Taking a flight? </b></h4>
                                    <a href="#">Click to check travel guidelines</a>
                              </div>
                        </div>
                  </div>
            </div>
      </section>
      <section class="location-slider-section section-padding">
            <div class="container px-0">
                  <div class="px-3 section-title d-flex align-items-end justify-content-between">
                        <div class="title-left st-animate">
                              <h2 class="fw-500">Lightning Deals</h2>
                        </div>
                  </div>
                  <div class="section-content-slick-slider mt-4">
                        <section class="slider">
                              <div data-index="1" class="slick-slide" tabindex="-1" aria-hidden="true"
                                    style="outline: none; width: 295px;">
                                    <div>
                                          <a href="#" target="_blank" rel="noreferrer">
                                                <div class="package-item cursor-pointer">
                                                      <div class="image-area">
                                                            <div class="image"><img loading="lazy"
                                                                        src="./assets/images/slider/1.jpg"
                                                                        alt="Dubai: The city of Gold!" />
                                                            </div>
                                                            <div
                                                                  class="taglines d-flex align-items-center justify-content-between">
                                                                  <div
                                                                        class="timer d-flex align-items-center fz12 primary-tag">
                                                                        <i
                                                                              class="far fa-clock mr-2"></i><span>42:02:28:58</span>
                                                                  </div>
                                                                  <div
                                                                        class="tag d-flex align-items-center fz12 primary-tag">
                                                                        <i class="fas fa-bolt mr-2"></i>
                                                                        <span>Trending</span>
                                                                  </div>
                                                            </div>
                                                      </div>
                                                      <h6 class="title fw-400 black-color">
                                                            Dubai: The city
                                                            of Gold!...</h6>
                                                      <div
                                                            class="tour-info d-flex align-items-center justify-content-start fz13">
                                                            <div
                                                                  class="duration d-flex align-items-center mr-2 text-nowrap">
                                                                  <i class="mdi mdi-calendar mr-1"></i>3
                                                                  Day
                                                            </div>
                                                            <div class="loacation d-flex align-items-center">
                                                                  <i class="mdi mdi-map-marker mr-1"></i>
                                                                  <div class="text-ellipsis">
                                                                        Dubai, United
                                                                        Arab Emirates</div>
                                                            </div>
                                                      </div>
                                                      <p class="fz12">Starts from ( with
                                                            Airfare)</p>
                                                      <div class="d-flex align-items-center mb-2 black-color">
                                                            <span class="fz16 fw-600"><span>BDT
                                                                        64,900</span>
                                                                  /<small>person</small></span>
                                                      </div>
                                                      <div
                                                            class="fz14 d-flex align-items-center fz14 fw-500 mb-1 black-color">
                                                            <i class="fa-solid fa-bangladeshi-taka-sign mr-2"></i>
                                                            <span><span> 5,900</span></span>
                                                      </div>
                                                </div>
                                          </a>
                                    </div>
                              </div>
                              <div data-index="2" class="slick-slide" tabindex="-1" aria-hidden="true"
                                    style="outline: none; width: 295px;">
                                    <div>
                                          <a href="#" target="_blank" rel="noreferrer">
                                                <div class="package-item cursor-pointer">
                                                      <div class="image-area">
                                                            <div class="image"><img loading="lazy"
                                                                        src="./assets/images/slider/2.jpg"
                                                                        alt="Dubai: The city of Gold!" />
                                                            </div>
                                                            <div
                                                                  class="taglines d-flex align-items-center justify-content-between">
                                                                  <div
                                                                        class="timer d-flex align-items-center fz12 primary-tag">
                                                                        <i
                                                                              class="far fa-clock mr-2"></i><span>42:02:28:58</span>
                                                                  </div>
                                                                  <div
                                                                        class="tag d-flex align-items-center fz12 primary-tag">
                                                                        <i class="fas fa-bolt mr-2"></i>
                                                                        <span>Trending</span>
                                                                  </div>
                                                            </div>
                                                      </div>
                                                      <h6 class="title fw-400 black-color">
                                                            Dubai: The city
                                                            of Gold!...</h6>
                                                      <div
                                                            class="tour-info d-flex align-items-center justify-content-start fz13">
                                                            <div
                                                                  class="duration d-flex align-items-center mr-2 text-nowrap">
                                                                  <i class="mdi mdi-calendar mr-1"></i>3
                                                                  Day
                                                            </div>
                                                            <div class="loacation d-flex align-items-center">
                                                                  <i class="mdi mdi-map-marker mr-1"></i>
                                                                  <div class="text-ellipsis">
                                                                        Dubai, United
                                                                        Arab Emirates</div>
                                                            </div>
                                                      </div>
                                                      <p class="fz12">Starts from ( with
                                                            Airfare)</p>
                                                      <div class="d-flex align-items-center mb-2 black-color">
                                                            <span class="fz16 fw-600"><span>BDT
                                                                        64,900</span>
                                                                  /<small>person</small></span>
                                                      </div>
                                                      <div
                                                            class="fz14 d-flex align-items-center fz14 fw-500 mb-1 black-color">
                                                            <i class="fa-solid fa-bangladeshi-taka-sign mr-2"></i>
                                                            <span><span> 5,900</span></span>
                                                      </div>
                                                </div>
                                          </a>
                                    </div>
                              </div>
                              <div data-index="3" class="slick-slide" tabindex="-1" aria-hidden="true"
                                    style="outline: none; width: 295px;">
                                    <div>
                                          <a href="#" target="_blank" rel="noreferrer">
                                                <div class="package-item cursor-pointer">
                                                      <div class="image-area">
                                                            <div class="image"><img loading="lazy"
                                                                        src="./assets/images/slider/3.jpg"
                                                                        alt="Dubai: The city of Gold!" />
                                                            </div>
                                                            <div
                                                                  class="taglines d-flex align-items-center justify-content-between">
                                                                  <div
                                                                        class="timer d-flex align-items-center fz12 primary-tag">
                                                                        <i
                                                                              class="far fa-clock mr-2"></i><span>42:02:28:58</span>
                                                                  </div>
                                                                  <div
                                                                        class="tag d-flex align-items-center fz12 primary-tag">
                                                                        <i class="fas fa-bolt mr-2"></i>
                                                                        <span>Trending</span>
                                                                  </div>
                                                            </div>
                                                      </div>
                                                      <h6 class="title fw-400 black-color">
                                                            Dubai: The city
                                                            of Gold!...</h6>
                                                      <div
                                                            class="tour-info d-flex align-items-center justify-content-start fz13">
                                                            <div
                                                                  class="duration d-flex align-items-center mr-2 text-nowrap">
                                                                  <i class="mdi mdi-calendar mr-1"></i>3
                                                                  Day
                                                            </div>
                                                            <div class="loacation d-flex align-items-center">
                                                                  <i class="mdi mdi-map-marker mr-1"></i>
                                                                  <div class="text-ellipsis">
                                                                        Dubai, United
                                                                        Arab Emirates</div>
                                                            </div>
                                                      </div>
                                                      <p class="fz12">Starts from ( with
                                                            Airfare)</p>
                                                      <div class="d-flex align-items-center mb-2 black-color">
                                                            <span class="fz16 fw-600"><span>BDT
                                                                        64,900</span>
                                                                  /<small>person</small></span>
                                                      </div>
                                                      <div
                                                            class="fz14 d-flex align-items-center fz14 fw-500 mb-1 black-color">
                                                            <i class="fa-solid fa-bangladeshi-taka-sign mr-2"></i>
                                                            <span><span> 5,900</span></span>
                                                      </div>
                                                </div>
                                          </a>
                                    </div>
                              </div>
                              <div data-index="4" class="slick-slide" tabindex="-1" aria-hidden="true"
                                    style="outline: none; width: 295px;">
                                    <div>
                                          <a href="#" target="_blank" rel="noreferrer">
                                                <div class="package-item cursor-pointer">
                                                      <div class="image-area">
                                                            <div class="image"><img loading="lazy"
                                                                        src="./assets/images/slider/4.jpg"
                                                                        alt="Dubai: The city of Gold!" />
                                                            </div>
                                                            <div
                                                                  class="taglines d-flex align-items-center justify-content-between">
                                                                  <div
                                                                        class="timer d-flex align-items-center fz12 primary-tag">
                                                                        <i
                                                                              class="far fa-clock mr-2"></i><span>42:02:28:58</span>
                                                                  </div>
                                                                  <div
                                                                        class="tag d-flex align-items-center fz12 primary-tag">
                                                                        <i class="fas fa-bolt mr-2"></i>
                                                                        <span>Trending</span>
                                                                  </div>
                                                            </div>
                                                      </div>
                                                      <h6 class="title fw-400 black-color">
                                                            Dubai: The city
                                                            of Gold!...</h6>
                                                      <div
                                                            class="tour-info d-flex align-items-center justify-content-start fz13">
                                                            <div
                                                                  class="duration d-flex align-items-center mr-2 text-nowrap">
                                                                  <i class="mdi mdi-calendar mr-1"></i>3
                                                                  Day
                                                            </div>
                                                            <div class="loacation d-flex align-items-center">
                                                                  <i class="mdi mdi-map-marker mr-1"></i>
                                                                  <div class="text-ellipsis">
                                                                        Dubai, United
                                                                        Arab Emirates</div>
                                                            </div>
                                                      </div>
                                                      <p class="fz12">Starts from ( with
                                                            Airfare)</p>
                                                      <div class="d-flex align-items-center mb-2 black-color">
                                                            <span class="fz16 fw-600"><span>BDT
                                                                        64,900</span>
                                                                  /<small>person</small></span>
                                                      </div>
                                                      <div
                                                            class="fz14 d-flex align-items-center fz14 fw-500 mb-1 black-color">
                                                            <i class="fa-solid fa-bangladeshi-taka-sign mr-2"></i>
                                                            <span><span> 5,900</span></span>
                                                      </div>
                                                </div>
                                          </a>
                                    </div>
                              </div>
                              <div data-index="5" class="slick-slide" tabindex="-1" aria-hidden="true"
                                    style="outline: none; width: 295px;">
                                    <div>
                                          <a href="#" target="_blank" rel="noreferrer">
                                                <div class="package-item cursor-pointer">
                                                      <div class="image-area">
                                                            <div class="image"><img loading="lazy"
                                                                        src="./assets/images/slider/5.jpg"
                                                                        alt="Dubai: The city of Gold!" />
                                                            </div>
                                                            <div
                                                                  class="taglines d-flex align-items-center justify-content-between">
                                                                  <div
                                                                        class="timer d-flex align-items-center fz12 primary-tag">
                                                                        <i
                                                                              class="far fa-clock mr-2"></i><span>42:02:28:58</span>
                                                                  </div>
                                                                  <div
                                                                        class="tag d-flex align-items-center fz12 primary-tag">
                                                                        <i class="fas fa-bolt mr-2"></i>
                                                                        <span>Trending</span>
                                                                  </div>
                                                            </div>
                                                      </div>
                                                      <h6 class="title fw-400 black-color">
                                                            Dubai: The city
                                                            of Gold!...</h6>
                                                      <div
                                                            class="tour-info d-flex align-items-center justify-content-start fz13">
                                                            <div
                                                                  class="duration d-flex align-items-center mr-2 text-nowrap">
                                                                  <i class="mdi mdi-calendar mr-1"></i>3
                                                                  Day
                                                            </div>
                                                            <div class="loacation d-flex align-items-center">
                                                                  <i class="mdi mdi-map-marker mr-1"></i>
                                                                  <div class="text-ellipsis">
                                                                        Dubai, United
                                                                        Arab Emirates</div>
                                                            </div>
                                                      </div>
                                                      <p class="fz12">Starts from ( with
                                                            Airfare)</p>
                                                      <div class="d-flex align-items-center mb-2 black-color">
                                                            <span class="fz16 fw-600"><span>BDT
                                                                        64,900</span>
                                                                  /<small>person</small></span>
                                                      </div>
                                                      <div
                                                            class="fz14 d-flex align-items-center fz14 fw-500 mb-1 black-color">
                                                            <i class="fa-solid fa-bangladeshi-taka-sign mr-2"></i>
                                                            <span><span> 5,900</span></span>
                                                      </div>
                                                </div>
                                          </a>
                                    </div>
                              </div>
                              <div data-index="6" class="slick-slide" tabindex="-1" aria-hidden="true"
                                    style="outline: none; width: 295px;">
                                    <div>
                                          <a href="#" target="_blank" rel="noreferrer">
                                                <div class="package-item cursor-pointer">
                                                      <div class="image-area">
                                                            <div class="image"><img loading="lazy"
                                                                        src="./assets/images/slider/6.jpg"
                                                                        alt="Dubai: The city of Gold!" />
                                                            </div>
                                                            <div
                                                                  class="taglines d-flex align-items-center justify-content-between">
                                                                  <div
                                                                        class="timer d-flex align-items-center fz12 primary-tag">
                                                                        <i
                                                                              class="far fa-clock mr-2"></i><span>42:02:28:58</span>
                                                                  </div>
                                                                  <div
                                                                        class="tag d-flex align-items-center fz12 primary-tag">
                                                                        <i class="fas fa-bolt mr-2"></i>
                                                                        <span>Trending</span>
                                                                  </div>
                                                            </div>
                                                      </div>
                                                      <h6 class="title fw-400 black-color">
                                                            Dubai: The city
                                                            of Gold!...</h6>
                                                      <div
                                                            class="tour-info d-flex align-items-center justify-content-start fz13">
                                                            <div
                                                                  class="duration d-flex align-items-center mr-2 text-nowrap">
                                                                  <i class="mdi mdi-calendar mr-1"></i>3
                                                                  Day
                                                            </div>
                                                            <div class="loacation d-flex align-items-center">
                                                                  <i class="mdi mdi-map-marker mr-1"></i>
                                                                  <div class="text-ellipsis">
                                                                        Dubai, United
                                                                        Arab Emirates</div>
                                                            </div>
                                                      </div>
                                                      <p class="fz12">Starts from ( with
                                                            Airfare)</p>
                                                      <div class="d-flex align-items-center mb-2 black-color">
                                                            <span class="fz16 fw-600"><span>BDT
                                                                        64,900</span>
                                                                  /<small>person</small></span>
                                                      </div>
                                                      <div
                                                            class="fz14 d-flex align-items-center fz14 fw-500 mb-1 black-color">
                                                            <i class="fa-solid fa-bangladeshi-taka-sign mr-2"></i>
                                                            <span><span> 5,900</span></span>
                                                      </div>
                                                </div>
                                          </a>
                                    </div>
                              </div>
                              <div data-index="7" class="slick-slide" tabindex="-1" aria-hidden="true"
                                    style="outline: none; width: 295px;">
                                    <div>
                                          <a href="#" target="_blank" rel="noreferrer">
                                                <div class="package-item cursor-pointer">
                                                      <div class="image-area">
                                                            <div class="image"><img loading="lazy"
                                                                        src="./assets/images/slider/7.jpg"
                                                                        alt="Dubai: The city of Gold!" />
                                                            </div>
                                                            <div
                                                                  class="taglines d-flex align-items-center justify-content-between">
                                                                  <div
                                                                        class="timer d-flex align-items-center fz12 primary-tag">
                                                                        <i
                                                                              class="far fa-clock mr-2"></i><span>42:02:28:58</span>
                                                                  </div>
                                                                  <div
                                                                        class="tag d-flex align-items-center fz12 primary-tag">
                                                                        <i class="fas fa-bolt mr-2"></i>
                                                                        <span>Trending</span>
                                                                  </div>
                                                            </div>
                                                      </div>
                                                      <h6 class="title fw-400 black-color">
                                                            Dubai: The city
                                                            of Gold!...</h6>
                                                      <div
                                                            class="tour-info d-flex align-items-center justify-content-start fz13">
                                                            <div
                                                                  class="duration d-flex align-items-center mr-2 text-nowrap">
                                                                  <i class="mdi mdi-calendar mr-1"></i>3
                                                                  Day
                                                            </div>
                                                            <div class="loacation d-flex align-items-center">
                                                                  <i class="mdi mdi-map-marker mr-1"></i>
                                                                  <div class="text-ellipsis">
                                                                        Dubai, United
                                                                        Arab Emirates</div>
                                                            </div>
                                                      </div>
                                                      <p class="fz12">Starts from ( with
                                                            Airfare)</p>
                                                      <div class="d-flex align-items-center mb-2 black-color">
                                                            <span class="fz16 fw-600"><span>BDT
                                                                        64,900</span>
                                                                  /<small>person</small></span>
                                                      </div>
                                                      <div
                                                            class="fz14 d-flex align-items-center fz14 fw-500 mb-1 black-color">
                                                            <i class="fa-solid fa-bangladeshi-taka-sign mr-2"></i>
                                                            <span><span> 5,900</span></span>
                                                      </div>
                                                </div>
                                          </a>
                                    </div>
                              </div>
                              <div data-index="8" class="slick-slide" tabindex="-1" aria-hidden="true"
                                    style="outline: none; width: 295px;">
                                    <div>
                                          <a href="#" target="_blank" rel="noreferrer">
                                                <div class="package-item cursor-pointer">
                                                      <div class="image-area">
                                                            <div class="image"><img loading="lazy"
                                                                        src="./assets/images/slider/8.jpg"
                                                                        alt="Dubai: The city of Gold!" />
                                                            </div>
                                                            <div
                                                                  class="taglines d-flex align-items-center justify-content-between">
                                                                  <div
                                                                        class="timer d-flex align-items-center fz12 primary-tag">
                                                                        <i
                                                                              class="far fa-clock mr-2"></i><span>42:02:28:58</span>
                                                                  </div>
                                                                  <div
                                                                        class="tag d-flex align-items-center fz12 primary-tag">
                                                                        <i class="fas fa-bolt mr-2"></i>
                                                                        <span>Trending</span>
                                                                  </div>
                                                            </div>
                                                      </div>
                                                      <h6 class="title fw-400 black-color">
                                                            Dubai: The city
                                                            of Gold!...</h6>
                                                      <div
                                                            class="tour-info d-flex align-items-center justify-content-start fz13">
                                                            <div
                                                                  class="duration d-flex align-items-center mr-2 text-nowrap">
                                                                  <i class="mdi mdi-calendar mr-1"></i>3
                                                                  Day
                                                            </div>
                                                            <div class="loacation d-flex align-items-center">
                                                                  <i class="mdi mdi-map-marker mr-1"></i>
                                                                  <div class="text-ellipsis">
                                                                        Dubai, United
                                                                        Arab Emirates</div>
                                                            </div>
                                                      </div>
                                                      <p class="fz12">Starts from ( with
                                                            Airfare)</p>
                                                      <div class="d-flex align-items-center mb-2 black-color">
                                                            <span class="fz16 fw-600"><span>BDT
                                                                        64,900</span>
                                                                  /<small>person</small></span>
                                                      </div>
                                                      <div
                                                            class="fz14 d-flex align-items-center fz14 fw-500 mb-1 black-color">
                                                            <i class="fa-solid fa-bangladeshi-taka-sign mr-2"></i>
                                                            <span><span> 5,900</span></span>
                                                      </div>
                                                </div>
                                          </a>
                                    </div>
                              </div>
                        </section>
                  </div>

            </div>
      </section>
      <section class="">
            <div class="container">
                  <div class="section-title mb-4 st-animate">
                        <h2 class="fw-500">Packages in Popular Destinations</h2>
                  </div>
                  <div class="section-content">
                        <div class="row">
                              <div class="col-md-12 col-sm-6">
                                    <a class="black-color" href='#' target="_blank" rel="noreferrer">
                                          <div class="package-module large">
                                                <div class="image-area">
                                                      <div class="flex-img w-100"><img loading="lazy"
                                                                  src="./assets/images/feature1.png" alt="Dubai" />
                                                      </div>
                                                </div>
                                                <div class="info">
                                                      <div class="packages d-flex align-items-center">
                                                            <img loading="lazy" src="./assets/images/package.svg" alt=""
                                                                  class="icon mr-2" />
                                                            <p>20 Packages</p>
                                                      </div>
                                                      <h5 class="fw-500 title">Dubai</h5>
                                                      <div class="amount mr-sm-2">
                                                            <p>
                                                                  <span>Starts From
                                                                  </span><strong><span>BDT
                                                                              10,780</span></strong>
                                                            </p>
                                                      </div>
                                                </div>
                                          </div>
                                    </a>
                              </div>
                              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6">
                                    <a class="black-color" href='#' target="_blank" rel="noreferrer">
                                          <div class="package-module">
                                                <div class="image-area">
                                                      <div class="flex-img w-100"><img loading="lazy"
                                                                  src="./assets/images/f2.png" alt="Maldives" /></div>
                                                </div>
                                                <div class="info">
                                                      <div class="packages d-flex align-items-center">
                                                            <img loading="lazy" src="./assets/images/package.svg" alt=""
                                                                  class="icon mr-2" />
                                                            <p>23 Packages</p>
                                                      </div>
                                                      <h5 class="fw-500 title">Maldives</h5>
                                                      <div class="amount mr-sm-2">
                                                            <p>
                                                                  <span>Starts From
                                                                  </span><strong><span>BDT
                                                                              27,500</span></strong>
                                                            </p>
                                                      </div>
                                                </div>
                                          </div>
                                    </a>
                              </div>
                              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6">
                                    <a class="black-color" href='#' target="_blank" rel="noreferrer">
                                          <div class="package-module">
                                                <div class="image-area">
                                                      <div class="flex-img w-100"><img loading="lazy"
                                                                  src="./assets/images/f3.png" alt="Cairo" /></div>
                                                </div>
                                                <div class="info">
                                                      <div class="packages d-flex align-items-center">
                                                            <img loading="lazy" src="./assets/images/package.svg" alt=""
                                                                  class="icon mr-2" />
                                                            <p>7 Packages</p>
                                                      </div>
                                                      <h5 class="fw-500 title">Cairo</h5>
                                                      <div class="amount mr-sm-2">
                                                            <p>
                                                                  <span>Starts From
                                                                  </span><strong><span>BDT
                                                                              23,650</span></strong>
                                                            </p>
                                                      </div>
                                                </div>
                                          </div>
                                    </a>
                              </div>
                              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6">
                                    <a class="black-color" href='#' target="_blank" rel="noreferrer">
                                          <div class="package-module">
                                                <div class="image-area">
                                                      <div class="flex-img w-100"><img loading="lazy"
                                                                  src="./assets/images/f4.png" alt=" Colombo" /></div>
                                                </div>
                                                <div class="info">
                                                      <div class="packages d-flex align-items-center">
                                                            <img loading="lazy" src="./assets/images/package.svg" alt=""
                                                                  class="icon mr-2" />
                                                            <p>13 Packages</p>
                                                      </div>
                                                      <h5 class="fw-500 title">Colombo</h5>
                                                      <div class="amount mr-sm-2">
                                                            <p>
                                                                  <span>Starts From
                                                                  </span><strong><span>BDT
                                                                              6,160</span></strong>
                                                            </p>
                                                      </div>
                                                </div>
                                          </div>
                                    </a>
                              </div>
                              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6">
                                    <a class="black-color" href='#' target="_blank" rel="noreferrer">
                                          <div class="package-module">
                                                <div class="image-area">
                                                      <div class="flex-img w-100"><img loading="lazy"
                                                                  src="./assets/images/f5.png" alt="Kathmandu" /></div>
                                                </div>
                                                <div class="info">
                                                      <div class="packages d-flex align-items-center">
                                                            <img loading="lazy" src="./assets/images/package.svg" alt=""
                                                                  class="icon mr-2" />
                                                            <p>31 Packages</p>
                                                      </div>
                                                      <h5 class="fw-500 title">Kathmandu</h5>
                                                      <div class="amount mr-sm-2">
                                                            <p>
                                                                  <span>Starts From
                                                                  </span><strong><span>BDT
                                                                              5,280</span></strong>
                                                            </p>
                                                      </div>
                                                </div>
                                          </div>
                                    </a>
                              </div>
                              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6">
                                    <a class="black-color" href='#' target="_blank" rel="noreferrer">
                                          <div class="package-module">
                                                <div class="image-area">
                                                      <div class="flex-img w-100"><img loading="lazy"
                                                                  src="./assets/images/f6.png" alt="Agra" />
                                                      </div>
                                                </div>
                                                <div class="info">
                                                      <div class="packages d-flex align-items-center">
                                                            <img loading="lazy" src="./assets/images/package.svg" alt=""
                                                                  class="icon mr-2" />
                                                            <p>9 Packages</p>
                                                      </div>
                                                      <h5 class="fw-500 title">Agra</h5>
                                                      <div class="amount mr-sm-2">
                                                            <p>
                                                                  <span>Starts From
                                                                  </span><strong><span>BDT
                                                                              16,280</span></strong>
                                                            </p>
                                                      </div>
                                                </div>
                                          </div>
                                    </a>
                              </div>
                              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6">
                                    <a class="black-color" href='#' target="_blank" rel="noreferrer">
                                          <div class="package-module">
                                                <div class="image-area">
                                                      <div class="flex-img w-100"><img loading="lazy"
                                                                  src="./assets/images/f7.png" alt="Istanbul" /></div>
                                                </div>
                                                <div class="info">
                                                      <div class="packages d-flex align-items-center">
                                                            <img loading="lazy" src="./assets/images/package.svg" alt=""
                                                                  class="icon mr-2" />
                                                            <p>20 Packages</p>
                                                      </div>
                                                      <h5 class="fw-500 title">Istanbul</h5>
                                                      <div class="amount mr-sm-2">
                                                            <p>
                                                                  <span>Starts From
                                                                  </span><strong><span>BDT
                                                                              7,920</span></strong>
                                                            </p>
                                                      </div>
                                                </div>
                                          </div>
                                    </a>
                              </div>
                              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6">
                                    <a class="black-color" href='#' target="_blank" rel="noreferrer">
                                          <div class="package-module">
                                                <div class="image-area">
                                                      <div class="flex-img w-100"><img loading="lazy"
                                                                  src="./assets/images/f9.png" alt="Bangkok" /></div>
                                                </div>
                                                <div class="info">
                                                      <div class="packages d-flex align-items-center">
                                                            <img loading="lazy" src="./assets/images/package.svg" alt=""
                                                                  class="icon mr-2" />
                                                            <p>43 Packages</p>
                                                      </div>
                                                      <h5 class="fw-500 title">Bangkok</h5>
                                                      <div class="amount mr-sm-2">
                                                            <p>
                                                                  <span>Starts From
                                                                  </span><strong><span>BDT
                                                                              7,700</span></strong>
                                                            </p>
                                                      </div>
                                                </div>
                                          </div>
                                    </a>
                              </div>
                              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6">
                                    <a class="black-color" href='#' target="_blank" rel="noreferrer">
                                          <div class="package-module">
                                                <div class="image-area">
                                                      <div class="flex-img w-100"><img loading="lazy"
                                                                  src="./assets/images/f10.png" alt="Cox's Bazar" />
                                                      </div>
                                                </div>
                                                <div class="info">
                                                      <div class="packages d-flex align-items-center">
                                                            <img loading="lazy" src="./assets/images/package.svg" alt=""
                                                                  class="icon mr-2" />
                                                            <p>1 Packages</p>
                                                      </div>
                                                      <h5 class="fw-500 title">Cox's Bazar</h5>
                                                      <div class="amount mr-sm-2">
                                                            <p>
                                                                  <span>Starts From
                                                                  </span><strong><span>BDT
                                                                              220</span></strong>
                                                            </p>
                                                      </div>
                                                </div>
                                          </div>
                                    </a>
                              </div>
                        </div>
                  </div>
            </div>
      </section>
      <section class="section-padding">
            <div class="container">
                  <div class="section-title mb-4 st-animate">
                        <h2 class="fw-500">Search for cheapest flights in popular route</h2>
                  </div>
                  <div class="section-content">
                        <div class="row">
                              <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-xs-12 pl-2 pr-2">
                                    <div class="card-list-item">
                                          <span class="icon"><img loading="lazy" src="./assets/images/flight-mono.svg"
                                                      alt="" /></span>
                                          <h5 class="title fw-400">Dhaka - Coxs Bazar</h5>
                                          <p>From <strong>BDT 4,352</strong></p>
                                          <div class="arrow"><i class="mdi mdi-chevron-right"></i>
                                          </div>
                                    </div>
                              </div>
                              <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-xs-12 pl-2 pr-2">
                                    <div class="card-list-item">
                                          <span class="icon"><img loading="lazy" src="./assets/images/flight-mono.svg"
                                                      alt="" /></span>
                                          <h5 class="title fw-400">Dhaka - Kolkata</h5>
                                          <p>From <strong>BDT 6,987</strong></p>
                                          <div class="arrow"><i class="mdi mdi-chevron-right"></i>
                                          </div>
                                    </div>
                              </div>
                              <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-xs-12 pl-2 pr-2">
                                    <div class="card-list-item">
                                          <span class="icon"><img loading="lazy" src="./assets/images/flight-mono.svg"
                                                      alt="" /></span>
                                          <h5 class="title fw-400">Dhaka - Bangkok</h5>
                                          <p>From <strong>BDT 23,372</strong></p>
                                          <div class="arrow"><i class="mdi mdi-chevron-right"></i>
                                          </div>
                                    </div>
                              </div>
                              <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-xs-12 pl-2 pr-2">
                                    <div class="card-list-item">
                                          <span class="icon"><img loading="lazy" src="./assets/images/flight-mono.svg"
                                                      alt="" /></span>
                                          <h5 class="title fw-400">Dhaka - Jessore</h5>
                                          <p>From <strong>BDT 2,924</strong></p>
                                          <div class="arrow"><i class="mdi mdi-chevron-right"></i>
                                          </div>
                                    </div>
                              </div>
                              <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-xs-12 pl-2 pr-2">
                                    <div class="card-list-item">
                                          <span class="icon"><img loading="lazy" src="./assets/images/flight-mono.svg"
                                                      alt="" /></span>
                                          <h5 class="title fw-400">Dhaka - Chittagong</h5>
                                          <p>From <strong>BDT 3,369</strong></p>
                                          <div class="arrow"><i class="mdi mdi-chevron-right"></i>
                                          </div>
                                    </div>
                              </div>
                              <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-xs-12 pl-2 pr-2">
                                    <div class="card-list-item">
                                          <span class="icon"><img loading="lazy" src="./assets/images/flight-mono.svg"
                                                      alt="" /></span>
                                          <h5 class="title fw-400">Dhaka - Delhi</h5>
                                          <p>From <strong>BDT 12,695</strong></p>
                                          <div class="arrow"><i class="mdi mdi-chevron-right"></i>
                                          </div>
                                    </div>
                              </div>
                              <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-xs-12 pl-2 pr-2">
                                    <div class="card-list-item">
                                          <span class="icon"><img loading="lazy" src="./assets/images/flight-mono.svg"
                                                      alt="" /></span>
                                          <h5 class="title fw-400">Dhaka - Madras</h5>
                                          <p>From <strong>BDT 12,695</strong></p>
                                          <div class="arrow"><i class="mdi mdi-chevron-right"></i>
                                          </div>
                                    </div>
                              </div>
                              <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-xs-12 pl-2 pr-2">
                                    <div class="card-list-item">
                                          <span class="icon"><img loading="lazy" src="./assets/images/flight-mono.svg"
                                                      alt="" /></span>
                                          <h5 class="title fw-400">Dhaka - Kuala Lumpur</h5>
                                          <p>From <strong>BDT 31,988</strong></p>
                                          <div class="arrow"><i class="mdi mdi-chevron-right"></i>
                                          </div>
                                    </div>
                              </div>
                              <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-xs-12 pl-2 pr-2">
                                    <div class="card-list-item">
                                          <span class="icon"><img loading="lazy" src="./assets/images/flight-mono.svg"
                                                      alt="" /></span>
                                          <h5 class="title fw-400">Dhaka - London</h5>
                                          <p>From <strong>BDT 46,990</strong></p>
                                          <div class="arrow"><i class="mdi mdi-chevron-right"></i>
                                          </div>
                                    </div>
                              </div>
                              <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-xs-12 pl-2 pr-2">
                                    <div class="card-list-item">
                                          <span class="icon"><img loading="lazy" src="./assets/images/flight-mono.svg"
                                                      alt="" /></span>
                                          <h5 class="title fw-400">Dhaka - New York</h5>
                                          <p>From <strong>BDT 77,079</strong></p>
                                          <div class="arrow"><i class="mdi mdi-chevron-right"></i>
                                          </div>
                                    </div>
                              </div>
                              <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-xs-12 pl-2 pr-2">
                                    <div class="card-list-item">
                                          <span class="icon"><img loading="lazy" src="./assets/images/flight-mono.svg"
                                                      alt="" /></span>
                                          <h5 class="title fw-400">Dhaka - Kathmandu</h5>
                                          <p>From <strong>BDT 16,463</strong></p>
                                          <div class="arrow"><i class="mdi mdi-chevron-right"></i>
                                          </div>
                                    </div>
                              </div>
                              <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-xs-12 pl-2 pr-2">
                                    <div class="card-list-item">
                                          <span class="icon"><img loading="lazy" src="./assets/images/flight-mono.svg"
                                                      alt="" /></span>
                                          <h5 class="title fw-400">Dhaka - Sylhet Osmani</h5>
                                          <p>From <strong>BDT 3,191</strong></p>
                                          <div class="arrow"><i class="mdi mdi-chevron-right"></i>
                                          </div>
                                    </div>
                              </div>
                        </div>
                  </div>
            </div>
      </section>
      <section class="download-apps">
            <div class="container">
                  <div class="row">
                        <div class="col-md-7 col-sm-6">
                              <div class="image"><img loading="lazy" src="./assets/images/app.png" alt="" />
                              </div>
                        </div>
                        <div class="col-md-5 col-sm-6 d-flex align-items-center justify-content-center">
                              <div class="section-content text-center text-sm-left">
                                    <h4 class="fw-600">Download Rayan Trip App
                                          and Earn
                                          Trip Coin.</h4>
                                    <div class="button-group d-flex align-items-center">
                                          <a href="#" target="_blank" rel="noreferrer"><img loading="lazy"
                                                      src="./assets/images/appStore.png" alt="" /></a>
                                          <a href="#" target="_blank" rel="noreferrer"><img loading="lazy"
                                                      src="./assets/images/playStore.png" alt="" /></a>
                                    </div>
                                    <div class="button-group d-flex align-items-center">
                                          <a href="#" target="_blank" rel="noreferrer"><img loading="lazy" width="100"
                                                      src="./assets/images/QRCodeDT_QR-code.avif" alt="" /></a>
                                    </div>
                              </div>
                        </div>
                  </div>
            </div>
      </section>
      <section class="award-section">
            <div class="container">
                  <h5>Product Offering</h5>

                  <p>Flights, International Flights, Charter Flights, Hotels, International
                        Hotels,
                        Homestays
                        and Villas, Activities, Holidays In India, International Holidays, Book
                        Hotels From
                        UAE,
                        myBiz for Corporate Travel, Book Online Cabs, Book Bus Tickets, Book
                        Train Tickets,
                        Cheap
                        Tickets to India, Book Flights From US, Book Flights From UAE, Trip
                        Planner, Gift
                        Cards,
                        Trip Money, Trip Ideas, Travel Blog, PNR Status, MakeMyTrip Advertising
                        Solutions,
                        One Way
                        Cab</p>

                  <h5>MakeMyTrip</h5>

                  <p>About Us, Investor Relations, Careers, MMT Foundation, CSR Policy,
                        myPartner - Travel
                        Agent Portal, Foreign Exchange, List your hotel, Partners- Redbus,
                        Partners-
                        Goibibo,
                        Advertise with Us</p>

                  About the Site</h5>

                  <p>Customer Support, Payment Security, Privacy Policy, User Agreement, Terms
                        of Service,
                        More
                        Offices, Make A Payment, Work From Home, Report Security Issues
                  </p>

                  <h5>Top Hotels in India</h5>

                  <p>Fairmont Jaipur, St Regis Goa, Six Senses Fort Barwara, W Goa, Grand Hyatt
                        Goa,
                        Shangri-La
                        Bangalore, The St Regis Mumbai, Taj Rishikesh, Grand Hyatt Mumbai, Le
                        Meridien
                        Delhi,
                        Rambagh Palace Jaipur, Leela Palace Chennai, The Leela Palace Udaipur,
                        Taj Lake
                        Palace
                        Udaipur, Jw Marriott Chandigarh, Alila Diwa Goa, Le Meridien Goa, Taj
                        Lands End
                        Mumbai,
                        Itc Grand Chola Chennai, Itc Maratha Mumbai, Oberoi Udaivilas, Jai Mahal
                        Palace
                        Jaipur,
                        Taj Mahal Tower Mumbai, Marriott Suites Pune, Park Hyatt Chennai, The
                        Leela Palace
                        Jaipur,
                        Jw Marriott Mumbai Sahar, Jw Marriott Mumbai Juhu, The Ritz Carlton
                        Bengaluru, The
                        Oberoi
                        New Delhi, Taj Resort & Convention Centre Goa, Taj Bengal Kolkata, Taj
                        Coromandel
                        Chennai,
                        The Oberoi Gurgaon, The Westin Goa, Jw Marriott Hotel Pune, The Leela
                        Palace New
                        Delhi,
                        Taj West End Bengaluru, The Taj Mahal Palace Mumbai</p>

                  <h5>Top International hotels</h5>

                  <p>Adaaran Club Rannalhi, Marina Bay Sands Singapore, Coco Bodu Hithi, Taj
                        Dubai, Atlantis
                        Hotel Dubai, Amari Phuket, Jw Marriott Dubai, Armani Hotel Dubai, Grand
                        Hyatt Dubai,
                        Saii
                        Lagoon Maldives, Gevora Hotel Dubai, Hyatt Regency Dubai, Pan Pacific
                        Singapore, The
                        Palm
                        Dubai, Caesars Palace, Baiyoke Sky Hotel, Centara Pattaya Hotel, Embudu
                        Village,
                        Orchard
                        Hotel Singapore, Reethi Beach Resort, Ambassador Hotel Bangkok, Dusit
                        Thani Pattaya,
                        Shangri La Singapore, Sunbeam Hotel Pattaya, Taj Samudra Colombo,
                        Bangkok Palace
                        Hotel,
                        Hilton Pattaya, Novotel Phuket Resort, Taj Exotica Resort Maldives,
                        Village Hotel
                        Bugis,
                        Avani Atrium Bangkok, The Plaza New York, Village Hotel Albert Court,
                        Amari Pattaya
                  </p>

                  <h5>Quick Links</h5>

                  <p>Delhi Chennai Flights, Delhi Mumbai Flights, Delhi Goa Flights, Chennai
                        Mumbai flights,
                        Mumbai Hyderabad flights, Kolkata to Rupsi Flights, Rupsi to Guwahati
                        Flights,
                        Pasighat to
                        Guwahati Flights, Delhi to Khajuraho Flights, Cochin to Agatti Island
                        Flights,
                        Hotels in
                        Delhi, Hotels in Mumbai, Hotels In Goa, Hotels In Jaipur, Hotels In
                        Ooty, Hotels In
                        Udaipur, Hotels in Puri, Hotels In North Goa, Hotels In Rishikesh,
                        Honeymoon
                        Packages,
                        Kerala Packages, Kashmir Packages, Ladakh Packages, Goa Packages,
                        Thailand Packages,
                        Sri
                        Lanka Visa, Thailand Visa, Explore Goa, Explore Manali, Explore Shimla,
                        Explore
                        Jaipur,
                        Explore Srinagar</p>

                  <h5>Important Links</h5>

                  <p>Cheap Flights, Flight Status, Kumbh Mela, Domestic Airlines, International
                        Airlines,
                        Indigo, Spicejet, GoAir, Air Asia, Air India, Indian Railways, Trip
                        Ideas, Beaches,
                        Honeymoon Destinations, Romantic Destinations, Popular Destinations,
                        Resorts In
                        Udaipur,
                        Resorts In Munnar, Villas In Lonavala, Hotels in Thailand, Villas In
                        Goa, Domestic
                        Flight
                        Offers, International Flight Offers, UAE Flight Offers, USA, UAE, Saudi
                        Arabia, UK,
                        Oman
                  </p>

                  <h5>Corporate Travel</h5>

                  <p>Corporate Travel, Corporate Hotel Booking, Corporate Flight Booking,
                        Business Travel
                        for
                        SME, GST Invoice for International flights, Business Travel Solutions,
                        GST Invoice
                        for
                        Bus, Corporate Bus booking, myBiz - Best Business Travel Platform, GST
                        Invoice for
                        Flights, GST Invoice for Corporate Travel, GST Invoice for Hotels, myBiz
                        for Small
                        Business, Free cancellation on International Flights</p>
            </div>
      </section>

      <section>
            <div class="container py-5 why-us-section">
                  <div class="row">
                        <div class="col-md-4">
                              <h4 class="mb-4">Why MakeMyTrip?</h4>
                              <p>Established in 2000, MakeMyTrip has since positioned itself as
                                    one of the
                                    leading companies, providing great offers, competitive
                                    airfares,
                                    exclusive
                                    discounts, and a seamless online booking experience to many
                                    of its
                                    customers.
                                    The experience of booking your flight tickets, hotel stay,
                                    and holiday
                                    package
                                    through our desktop site or mobile app can be done with
                                    complete ease
                                    and no
                                    hassles at all. We also deliver amazing offers, such as
                                    Instant
                                    Discounts,
                                    Fare Calendar, MyRewardsProgram, MyWallet, and many more
                                    while updating
                                    them
                                    from time to time to better suit our customers’ evolving
                                    needs and
                                    demands.
                              </p>
                        </div>
                        <div class="col-md-4">
                              <h4 class="mb-4">Why MakeMyTrip?</h4>
                              <p>Established in 2000, MakeMyTrip has since positioned itself as
                                    one of the
                                    leading companies, providing great offers, competitive
                                    airfares,
                                    exclusive
                                    discounts, and a seamless online booking experience to many
                                    of its
                                    customers.
                                    The experience of booking your flight tickets, hotel stay,
                                    and holiday
                                    package
                                    through our desktop site or mobile app can be done with
                                    complete ease
                                    and no
                                    hassles at all. We also deliver amazing offers, such as
                                    Instant
                                    Discounts,
                                    Fare Calendar, MyRewardsProgram, MyWallet, and many more
                                    while updating
                                    them
                                    from time to time to better suit our customers’ evolving
                                    needs and
                                    demands.
                              </p>
                        </div>
                        <div class="col-md-4">
                              <h4 class="mb-4">Why MakeMyTrip?</h4>
                              <p>Established in 2000, MakeMyTrip has since positioned itself as
                                    one of the
                                    leading companies, providing great offers, competitive
                                    airfares,
                                    exclusive
                                    discounts, and a seamless online booking experience to many
                                    of its
                                    customers.
                                    The experience of booking your flight tickets, hotel stay,
                                    and holiday
                                    package
                                    through our desktop site or mobile app can be done with
                                    complete ease
                                    and no
                                    hassles at all. We also deliver amazing offers, such as
                                    Instant
                                    Discounts,
                                    Fare Calendar, MyRewardsProgram, MyWallet, and many more
                                    while updating
                                    them
                                    from time to time to better suit our customers’ evolving
                                    needs and
                                    demands.
                              </p>
                        </div>
                  </div>
            </div>
      </section>